    def wait_for_and_handle_events(self):
        """ Wait for each event to pass and then print the event. """
